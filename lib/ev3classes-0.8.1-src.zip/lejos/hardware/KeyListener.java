package lejos.hardware;

public interface KeyListener {
	
	public void keyPressed (Key k);
	
	public void keyReleased (Key k);

}

/**
 * Hardware abstraction interfaces for the robotics package.
 */
package lejos.robotics;

/**
 * Path finding classes.
 */
package lejos.robotics.pathfinding;

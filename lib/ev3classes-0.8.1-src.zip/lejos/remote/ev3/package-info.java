/**
 * Access to remove EV3s from an EV3 or a PC.
 * 
 * Mainly uses Java RMI.
 */
package lejos.remote.ev3;
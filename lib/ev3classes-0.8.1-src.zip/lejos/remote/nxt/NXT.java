package lejos.remote.nxt;

import lejos.hardware.Brick;

public interface NXT extends Brick
{

}
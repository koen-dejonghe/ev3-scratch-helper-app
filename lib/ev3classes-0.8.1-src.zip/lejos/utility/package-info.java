/**
 * More utility classes
 */
package lejos.utility;

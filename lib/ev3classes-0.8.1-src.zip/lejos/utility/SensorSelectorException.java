package lejos.utility;

public class SensorSelectorException extends Exception {

	public SensorSelectorException(String message) {
		super(message);
	}

}
